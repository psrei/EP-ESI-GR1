class Registro
    include Capybara::DSL

    #protótipo pré-desenvolvimento

    #element :campoNome , "."
    #element :campoSenha, "."

    def Registrar()
        #campoNome.set CONFIG["usuarios"]["adm"]
        #campoSenha.set CONFIG["usuarios"]["admSenha"]
    end











end