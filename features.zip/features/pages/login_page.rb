Dado('que eu estou logando com informações válidas') do
    pending # Write code here that turns the phrase above into concrete actions
  end
  
  Quando('tentar acessar o Correct') do
    pending # Write code here that turns the phrase above into concrete actions
  end
  
  Então('estarei logado Correct Redação') do
    pending # Write code here that turns the phrase above into concrete actions
  end
  
  Dado('que eu estou logando com informações errôneas') do
    pending # Write code here that turns the phrase above into concrete actions
  end
  
  Então('náo conseguirei Correct Redação') do
    pending # Write code here that turns the phrase above into concrete actions
  end