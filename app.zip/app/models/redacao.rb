class Redacao < ApplicationRecord
    validates :redacao, presence: { message: "É obrigatório inserir o texto!" }
end